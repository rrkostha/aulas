<?php
include('seguranca.php');
include('head.php');
include('menu.php');

?>
 
  <div class="container">





  
                     
   </div>   

   

    <?php 
    
    include('footer.php');
    
    ;?>