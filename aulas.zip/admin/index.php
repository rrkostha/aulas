<?php
include('seguranca.php');
include('head.php');
include('menu.php');

?>
 
  <div class="container login">


 
                     
   </div>   

   

    <?php 
    
    include('footer.php');
    
    ;?>