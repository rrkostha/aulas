<?php 

session_destroy();
    //Reendirecciona para a pagina index
header("location:../index.php");


;?>