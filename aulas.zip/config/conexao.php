<?php
//$conectar = mysqli_connect("localhost","rogerio","#Chp252625") or die ("Erro na conexão");
//mysqli_select_db("checkofertas")or die ("Base não encontrada");


//$link = mysqli_connect("localhost","rogerio","#Chp252625","checkofertas");
$link = mysqli_connect("localhost","iamir_aulas","#Chp252625","iamir_aulas");




mysqli_query($link, 'SET NAMES utf8');