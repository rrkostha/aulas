<?php
session_start();
unset($_SESSION['userid'],			
          $_SESSION['email'],
          $_SESSION['admin']);
include('head.php');
include('menu.php');


;?>
 
  <div class="container">
                        <div class="jumbotron">
                        <h1 class="display-4">Olá, bem vindo ao EAD Iamir Rio Preto II</h1>
                        <p class="lead">Este é um espaço facíl para você aprender.</p>
                        <hr class="my-4">
                        <p>Para se cadastrar clique no link abaixo</p>
                        <a class="btn btn-primary btn-lg" href=" http://api.whatsapp.com/send?1=pt_BR&phone=17997747442" role="button">Leia mais</a>
                        </div>
   </div>   

    <div class="container">

                            <div class="card" style="width: 18rem;">
                                      <img class="card-img-top" src="img/violao.png" alt="Imagem de capa do card">
                                <div class="card-body">
                                        <h5 class="card-title">Curso de violão</h5>
                                        <p class="card-text">Este curso é bem facíl.</p>
                                        <a href="listaraulasviolao.php" class="btn btn-primary">Aulas</a>
                                </div>
                           </div>

    </div>

    <?php 
    
    include('footer.php');
    
    ;?>